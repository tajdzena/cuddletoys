<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class IgrackaKombinacija extends Model
{
    use HasFactory;

    protected $table = 'igracka_kombinacija';

    protected $primaryKey = 'idIgrKomb';

    public $timestamps = false; // Ako ne koristite timestamps kolone

    protected $fillable = [
        'idIgrBoje',
        'idDimenzije',
        'cena_pravljenja',
    ];
}
