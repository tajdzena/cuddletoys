<div class="text-green">
    <a href="/" class="hover:underline">Početna strana</a>
    {{$slot}}
</div>
