@props(['putanja', 'alt'])

<div class="min-w-full">
    <x-slika putanja="{{$putanja}}" alt="{{$alt}}" h="64"></x-slika>
</div>
