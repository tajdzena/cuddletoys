<h1 class="font-bold text-center mt-5 mb-5 text-3xl text-purple">{{$slot}}</h1>


