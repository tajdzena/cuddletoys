<div class="min-h-screen py-8">
    <div class="container mx-auto px-4 max-w-7xl">
        {{$slot}}
    </div>
</div>
