@props(['putanja'])

<a href="{{$putanja}}" class="-ml-3 mr-4 block rounded-lg px-3 py-2 text-base font-semibold leading-7 text-dark-pink hover:bg-white/20">{{$slot}}</a>
