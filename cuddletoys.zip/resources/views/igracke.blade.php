<x-nav>
    <title>CuddleToys - Igračke</title>
</x-nav>

<x-glavni-div>
    <x-path>
        / <a href="/igracke" class="hover:underline"> Igračke</a>
    </x-path>

    <x-title>Prikaz svih igračaka</x-title>

    <div class="flex flex-col md:flex-row md:justify-between mb-6">
        <!-- Sortiranje -->
        <div>
            <label for="sort" class="block text-dark-pink font-semibold mb-2">Sortiraj po:</label>
            <x-select id="sort">
                <x-option value="" isDisabled="yes">Izaberi sortiranje</x-option>
                <x-option value="1">Cena (rastuće)</x-option>
                <x-option value="2">Cena (opadajuće)</x-option>
                <x-option value="3">Naziv (A-Š)</x-option>
                <x-option value="4">Naziv (Š-A)</x-option>
                <x-option value="5">Najnoviji</x-option>
            </x-select>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <!-- Primer proizvoda -->
        <x-card-proizvod putanja="images/igracke/zaba/zaba-zelena-crna.png" href="igracka" alt="Žaba" naziv="Žaba" cena="2000 RSD"></x-card-proizvod>
        <x-card-proizvod putanja="images/igracke/slon/slon-siva-crna.png" href="igracka" alt="Slon" naziv="Slon" cena="2000 RSD"></x-card-proizvod>
        <x-card-proizvod putanja="images/igracke/patka/patka-zuta-crna.png" href="igracka" alt="Patka" naziv="Patka" cena="2000 RSD"></x-card-proizvod>
        <x-card-proizvod putanja="images/igracke/meda/meda-braon-crna.png" href="igracka" alt="Meda" naziv="Meda" cena="2000 RSD"></x-card-proizvod>
    </div>
</x-glavni-div>

<x-footer />
